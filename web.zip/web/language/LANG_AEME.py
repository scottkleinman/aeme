""" Python variables must be all upper case and temporary variables
all lower case. This ensures the creation of readable dictionaries in 
this file without duplicating material in the JSON object passed to 
the template.
"""
