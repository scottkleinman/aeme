The `<fileDesc>` contains the full bibliographic description of the electronic file.

### Required Child Elements
`<titleStmt>`, `<publicationStmt>`, `<sourceDesc>`
