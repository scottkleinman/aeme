The `<msDesc>` contains a description of a single identifiable manuscript or other text-bearing object. This may include manuscripts in estranged parts which may now be located in separate repositories.

### Required Child Elements

`<msIdentifier>`, `<msContents>`, `<physDesc>`, `<history>`, `<additional>`
