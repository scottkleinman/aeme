The `<msContents>` element is effectively a table of contents for the manuscript. Each item is numbered using `<msItem n="1">`, `<msItem n="2">`, etc.

### Required Child Elements

`<msItem>`
