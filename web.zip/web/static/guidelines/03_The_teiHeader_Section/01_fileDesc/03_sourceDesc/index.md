The `<sourceDesc>` contains a bibliographic description of the source from which the electronic text has been established.

### Required Child Elements

`<msDesc>`
