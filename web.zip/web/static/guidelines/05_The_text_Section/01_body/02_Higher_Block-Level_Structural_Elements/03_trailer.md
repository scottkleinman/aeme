`<trailer>` should be used exclusively for material at the end of a text section (generally right before the end tag of a numbered `div`). It is typically used for explicits. `<trailer>` will often contain the same material as `<finalRubric>` if it is present in an `<msItem>` entry.

Extra-textual information in the bottom margin of a page should be encoded with `<fw>` or `<ab>`.
