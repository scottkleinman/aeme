<p class="lead">
This document is a reference for editors who are encoding texts for the Archive of Early Middle English (AEME). All files submitted to the Archive must conform to the minimal Guidelines in the document. Encoding not specified in the Guidelines is allowable but may not be visible in the rendered texts on the AEME web platform.
</p>