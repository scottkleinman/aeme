# Developer's Note

According to the GitHub repo [https://github.com/sydcanem/bootstrap-contextmenu](https://github.com/sydcanem/bootstrap-contextmenu), this plugin is no longer maintained. The author recommends that we use [https://github.com/swisnl/jQuery-contextMenu](https://github.com/swisnl/jQuery-contextMenu).

We should consider changing for Lexos 3.5

--Scott Kleinman